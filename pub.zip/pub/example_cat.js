

const title = document.getElementById("title").innerHTML;
const side = new makeSideStepBar(title);
const getCont = new getContent();                 //have undefined children